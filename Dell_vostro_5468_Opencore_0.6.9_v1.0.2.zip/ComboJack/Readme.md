## Hackintosh ComboJack Support For ALC256

1. Open Terminal, type sh (space) then drag install.sh to it and hit enter.

2. Done.

![combojack](https://github.com/tuankhang99/VOSTRO-3568-EFI/blob/main/screenshot/2.png)

![combojack](https://github.com/tuankhang99/VOSTRO-3568-EFI/blob/main/screenshot/3.png)
